# Raman Xc Mapper

a-Si(비정질 실리콘) 박막의 레이저 결정화 공정을 25×25 grid(625 points) Raman mapping 데이터로 정량 분석하는 웹 기반 시각화 도구. 기존 MATLAB 파이프라인의 분석 로직을 Plotly.js 기반 인터랙티브 웹 앱으로 재구현했다.

## 배경 및 목적

Single-shot 레이저 결정화 실험에서 공간적 결정성 분포를 빠르게 확인하고, 공정 조건(fluence, beam profile)과의 상관관계를 시각적으로 검토하기 위해 개발했다. MATLAB에서 수동으로 반복하던 분석 단계를 자동화하고, 공유 가능한 단일 파일 웹 앱으로 재구성했다.

## 핵심 기능

- **Grid mapping 및 좌표 보정**: 파일 업로드 시 point-symmetry 보정(kfile = N − rasterIndex + 1) 자동 적용 — 측정 소프트웨어의 reverse raster 저장 방식에 맞춘 좌표 정렬.
- **Despike filtering**: Median filter 기반 MAD threshold로 스파이크 노이즈 제거.
- **결정화율 계산**: a-Si/c-Si peak band integration → Xc = Ic / (Ic + α·Ia)
- **3종 동기화 히트맵**: a-Si, c-Si, Xc 맵을 동일 좌표계(10µm tick)로 동시 표시.
- **Cross-section 프로파일**: a-Si/c-Si/Xc를 dual y-axis로 겹쳐 표시.
- **Zone classification**: φ = Ic/(Ic+Ia) 기반 dual-handle 슬라이더로 Amorphous/Partial/Crystallized 영역 구분.
- **Radial profile 및 Gaussian beam overlay**: Ic/Ia 교차점 탐지로 threshold fluence 추정.
- **Colormap 선택, 줌/리셋, 배치 이미지 export** 등 실사용 편의 기능.

## 기술 스택

- 순수 HTML/JavaScript + Plotly.js (CDN)

## 핵심 분석적 판단

- **α 파라미터 불확실성**: Xc의 절대값은 α(문헌상 0.1–1.7 범위, 여기광 파장·결정립 크기에 의존)에 크게 좌우되어 신뢰하기 어려움. 다만 **공간적 상대 패턴은 α 선택과 무관하게 불변**이므로, 절대값이 아닌 상대 분포로 결론을 도출하는 방식을 채택.
- **φ vs 절대값**: φ는 focus drift·power variation 같은 common-mode 변동을 상쇄하지만, 절대 Ic/Ia는 신호 세기에 대한 독립적 정보를 담고 있어 상호 보완적으로 사용.
- **Otsu thresholding의 한계**: 데이터가 항상 bimodal distribution을 보이지 않아 signal floor 자동 검출에는 부적합. φ classification에만 제한적으로 적용하고, signal floor는 수동 제어(기본값 2%)로 전환.

## 실행 방법

`index.html`을 브라우저에서 직접 열면 된다. 별도 서버나 빌드 과정 불필요.
