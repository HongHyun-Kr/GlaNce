# Laser Process AI Portfolio

355nm UV 나노초 레이저 기반 박막 결정화·표면 미세구조 형성 연구 과정에서, 반복되는 실험 설계·데이터 분석·장비 운용 작업을 AI(Claude)를 활용해 직접 도구화한 웹 기반 애플리케이션 3종.

각 도구는 단일 파일 HTML/JS로 구현되어 별도 설치 없이 브라우저에서 바로 실행 가능하며, 실제 연구실 실측 데이터와 논문 게재 파라미터를 기준값으로 사용한다.

## 프로젝트 목록

| 프로젝트 | 설명 | 폴더 |
|---|---|---|
| **BeamPath — Virtual Optics System** | 광학계 fluence/spot size 실시간 계산 및 애니메이션 광경로 시뮬레이터 | [`01-beampath-optics-calculator`](./01-beampath-optics-calculator) |
| **Raman Xc Mapper** | a-Si 결정화 Raman mapping 데이터 정량 분석 및 시각화 도구 | [`02-raman-xc-mapper`](./02-raman-xc-mapper) |
| **SCANLAB Studio** | 레이저 스캐너 툴패스 설계·시뮬레이션·검증 도구 (실장비 검증 완료) | [`03-scanlab-studio`](./03-scanlab-studio) |

## 공통 배경

- 연구실 장비: RAYLASE BS-4E-20TYI 스캐너(galvo + F-theta lens, f=255mm), 355nm UV 나노초 Poplar 레이저, SCANLAB/laserDESK 소프트웨어
- 기준 파라미터: 자체 게재 논문의 focal waist, M², rep rate, pulse width 실측값
- 개발 방식: 각 도구를 AI(Claude)와의 반복적 대화를 통해 요구사항 정의 → 프로토타입 → 실측 데이터 검증 → 개선의 사이클로 개발

## AI 활용 포인트

세 도구 모두 "AI를 단순 코드 생성기가 아니라, 물리적 도메인 지식(광학, 결정화 메커니즘, 스캐너 제어)을 정확히 반영한 실무 도구를 만드는 협업 파트너"로 활용한 사례. 각 프로젝트 README에 세부 기술적 판단(예: Raman α 파라미터 불확실성 처리, SCANLAB 단위 오차 대응)을 기록해 두었다.

## License

개인 연구/포트폴리오 목적. 별도 명시 전까지 재배포 제한.
