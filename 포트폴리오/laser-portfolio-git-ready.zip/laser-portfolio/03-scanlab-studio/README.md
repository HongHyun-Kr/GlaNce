# SCANLAB Studio

레이저 스캐너(RAYLASE, SCANLAB/laserDESK 기반) 툴패스를 설계하고 물리적 실행 전 미리 시각화하는 단일 파일 HTML 도구. 실제 장비에 스캔 패턴을 물리적으로 실행하기 전, 예상치 못한 경로/속도 오류로 인한 장비 시간 낭비를 방지하기 위해 개발했다.

## 배경 및 목적

SCANLAB 시스템은 single-stroke(Eulerian) 경로만 실행 가능하다는 제약이 있어, 코드만으로 복잡한 툴패스를 예측하면 실제 장비에서 예상과 다르게 동작하는 경우가 많았다. 이 도구는 실행 전 경로 형태·속도 분포·타이밍을 시각적으로 검증할 수 있게 한다. 실제 장비에서 물리적 스캔 실행까지 성공적으로 검증되었다.

## 핵심 기능

- **Drawing 탭**: 펜/도형/올가미 툴, 이미지 업로드 후 contour 자동 추출.
- **Contour 추출 파이프라인**: Marching squares → Douglas-Peucker 알고리즘으로 이미지 윤곽선을 스캔 가능한 벡터 경로로 변환.
- **경로 최적화**: Nearest-neighbor + 2-opt 알고리즘으로 이동 거리를 최소화하는 스캔 순서 산출.
- **Beam Path Viewer 탭**: 시간 기반 애니메이션으로 실제 빔 이동을 재생, 속도에 따른 컬러 매핑, HUD로 실시간 파라미터 표시.
- **MATLAB preamble interpreter**: 기존 MATLAB 기반 스캔 코드 프리앰블을 해석해 웹에서 재현.
- **Dual-path 비교**: 두 경로안을 나란히 비교.
- **.sld export**: UTF-16LE 인코딩으로 SCANLAB/laserDESK가 인식하는 포맷으로 직접 export.

## 기술 스택

- 순수 HTML/JavaScript (Canvas 기반 렌더링)
- 이미지 처리: Marching squares, Douglas-Peucker simplification
- 경로 최적화: Nearest-neighbor construction + 2-opt local search

## 핵심 교훈

- **단위 불일치의 위험성**: .sld export 과정에서 mm/s와 m/s 단위를 혼동한 1000배 오차가 발생, 이로 인한 silent failure를 실제로 겪음 — 물리 파라미터는 반드시 실제 장비 스키마와 대조 검증해야 함을 확인.
- **시각화의 필요성**: 복잡한 툴패스는 코드만으로 예측하기 어렵고, 하드웨어 실행 전 시각적 검증이 장비 시간 낭비를 막는 데 필수적임.

## 실행 방법

`index.html`을 브라우저에서 직접 열면 된다. 별도 서버나 빌드 과정 불필요.
