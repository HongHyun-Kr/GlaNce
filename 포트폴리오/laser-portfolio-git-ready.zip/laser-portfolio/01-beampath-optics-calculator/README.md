# BeamPath — Virtual Optics System

355nm UV 나노초 레이저 공정 라인의 광학계를 웹 기반으로 시뮬레이션하는 단일 파일 HTML 애플리케이션. RAYLASE BS-4E-20TYI 스캐너(F-theta lens, f=255mm) 기반 실제 랩 셋업을 애니메이션 광경로로 재현하고, Gaussian beam propagation 모델로 실시간 fluence/spot size를 계산한다.

## 배경 및 목적

랩에서 공정 조건(fluence, defocus)을 잡을 때마다 수식을 반복 계산하던 작업을 도구화했다. 동시에 "AI를 활용해 연구실 실무 도구를 직접 설계·구현할 수 있다"는 것을 보여주는 포트폴리오 artifact로 기획했다.

## 핵심 기능

- **애니메이션 광경로 뷰**: Atten., Shutter, BET, M1–M5 mirror, Waveplate, Scanner, Stage로 구성된 실제 광학계 토폴로지를 SVG 일러스트레이션으로 구현. 컴포넌트별 on/off 토글 지원 (경로 형태는 고정, 통과 여부만 변경).
- **Gaussian beam propagation 계산**: 논문에서 실측한 focal waist(w₀′=96μm, 1/e² 반경), M²=1.2를 기준값으로 Rayleigh range 및 defocus에 따른 spot size 변화를 계산.
- **Stage height (defocus) 슬라이더**: 스캐너–스테이지 거리(h_p = distance − 255mm)를 조절해 실시간 fluence 변화 확인.
- **Beam profile heatmap**: Canvas 기반, Jet colormap, X/Y cross-section, 3D isometric 뷰 옵션.
- **Reverse-solve 계산기**: 목표 fluence 또는 목표 spot diameter를 입력하면 필요한 stage 거리를 역산.
- **레이저 소스 파라미터 선택**: rep rate, pulse width, 평균 출력 등 실측 파라미터 기반.

## 기술 스택

- 순수 HTML/CSS/JavaScript (외부 프레임워크 없음, CDN 폰트만 사용)
- SVG 애니메이션, Canvas 기반 히트맵 렌더링

## 물리적 배경

- Rayleigh range: z_R = π·w₀′² / (λ·M²)
- 실측 기준값: f = 255mm, w₀′ = 96μm, M² = 1.2, rep rate 50kHz, pulse width 17ns (자체 게재 논문 데이터)

## 향후 계획 (Phase 2)

MATLAB raster scan 생성 로직(Group 단위 배치, scan/line pitch, .sld 파일 포맷)을 웹으로 재현하는 스캔 패턴 시뮬레이터 추가 예정.

## 실행 방법

`index.html`을 브라우저에서 직접 열면 된다. 별도 서버나 빌드 과정 불필요.
